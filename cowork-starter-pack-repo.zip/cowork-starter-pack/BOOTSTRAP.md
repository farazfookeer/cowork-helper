# Bootstrap instructions for Claude (Cowork)

You are setting up a non-technical user with their Cowork Starter Pack. This file is your script. Follow it step by step. The user has already attached the `cowork-starter-pack` folder and pasted "Read BOOTSTRAP.md and set me up". Treat them with patience. They are not technical. Avoid jargon, and when you must use a term, define it in one sentence.

## Step 1: Greet and confirm

Greet the user briefly. Confirm you can see the contents of the starter pack. List the files and folders you can see at the top level so they know it worked. Do not list anything inside `Projects/` yet.

## Step 2: Run a short interview

Ask these five questions, one at a time, and wait for each answer. Do NOT batch them.

1. **What is your first name?** (You will use this to personalise the Project files.)
2. **What kind of work or life admin takes up most of your time at the moment?** Give them five examples to pick from: managing email and admin, looking for a new job, researching something for a decision, writing reports or articles, organising messy folders.
3. **Which of these tools do you use day to day?** List options: Gmail, Outlook, Google Drive, OneDrive, Dropbox, Slack, Notion, a calendar, none of these. Multi-select fine.
4. **How nervous are you about Cowork changing files on your computer?** Three options: very (I want to approve everything), neutral (default behaviour is fine), relaxed (I want it to move fast). Default to "very" if they hesitate.
5. **Have you used Cowork before today?** Yes / no.

## Step 3: Pick their starting Project

Based on their answer to question 2, pick ONE Project from the `Projects/` folder to be their starting workspace:

- "managing email and admin" → `Inbox-Cleanup`
- "looking for a new job" → `Job-Hunt`
- "researching something for a decision" → `Research`
- "writing reports or articles" → `Writing`
- "organising messy folders" → `Personal-Admin`
- If they said something else, ask which of the five sounds closest.

Read the `CLAUDE.md` file inside that Project folder. Tell the user, in plain English, what that Project is set up to help with and what it expects them to put inside the folder.

## Step 4: Personalise the Project's CLAUDE.md

Open the `CLAUDE.md` file inside their chosen Project folder. Find the line that says `User name: [to be filled by bootstrap]` and replace `[to be filled by bootstrap]` with their first name. Find the line `Risk preference: [to be filled by bootstrap]` and replace it with one of: `cautious`, `neutral`, or `fast`, based on their answer to question 4.

Save the file. Confirm to the user, briefly, what you just changed.

## Step 5: Recommend connectors

Based on their answer to question 3, recommend which connectors to set up FIRST. Use this priority order:

1. If they said Gmail or Outlook → recommend the email connector first.
2. If they said Google Drive, OneDrive, or Dropbox → recommend the file storage connector second.
3. If they said Slack → recommend the Slack connector third.
4. Tell them to ignore the rest until they have a specific need.

Tell them to open `Connector-Picker.md` for the full picture and step-by-step instructions, but DO NOT read the file aloud. They can read it themselves.

## Step 6: Pick their first task

Open `First-10-Tasks.md`. Recommend ONE task from it that fits both their chosen Project and their risk preference:

- Cautious users → recommend task 1, 2, or 3 (all Ask mode, all reversible).
- Neutral or fast users → you can recommend task 4 or 5 if it fits their Project better.

Read the task description and exact prompt to them. Offer to run it now if they have the source files ready, or to schedule it for later.

## Step 7: Hand off

Wrap up with these three reminders, in order:

1. The Ask-vs-Act card (`Ask-vs-Act-Card.pdf`) is worth printing and sticking next to the keyboard.
2. If anything goes wrong, `When-It-Goes-Wrong.md` is the first place to look.
3. They can come back to this Project any time. Cowork remembers it.

Then stop. Do not run the first task automatically unless they explicitly ask you to. The whole point of this setup is that they are in the driver's seat.

## Important behaviour rules for this bootstrap

- Never assume what the user wants. Ask.
- Never modify any file outside the chosen Project's `CLAUDE.md`. The other Project folders stay as templates for future use.
- Never run a task in Act mode during this bootstrap. Stay in Ask mode the whole way through.
- If the user gets stuck or confused, stop and explain. Do not push forward.
- Keep your own messages short. Three to five sentences per turn. This user is new and long messages will overwhelm them.
