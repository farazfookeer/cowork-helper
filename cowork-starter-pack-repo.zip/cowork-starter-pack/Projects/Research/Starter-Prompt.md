# Research – starter prompt

You can use this Project two ways: with documents you already have, or with a question and let Cowork do the finding.

## If you have source documents

Drop them in the Project folder and paste:

> I have a question I am trying to answer: [YOUR QUESTION]. The documents in this folder are what I have gathered so far. Read all of them and tell me: what they collectively say about the question, where they agree, where they disagree, what is missing, and your tentative answer with the reasoning. Save it as research-notes.md.

## If you are starting from scratch

Paste:

> I am trying to make a decision about [YOUR QUESTION]. My constraints are: [BUDGET, TIMELINE, ANYTHING NON-NEGOTIABLE]. Search the web for credible sources, find three to five that are genuinely useful (not SEO sludge), and produce a comparison covering: the main options I should consider, the criteria that actually matter for this decision, a table comparing the options on those criteria, and your tentative recommendation. Save it as research-notes.md and list every source you used at the bottom.

After Cowork comes back, the most useful follow-up is almost always:

> What did you find that you are least confident about, and what would I need to do to verify it?
