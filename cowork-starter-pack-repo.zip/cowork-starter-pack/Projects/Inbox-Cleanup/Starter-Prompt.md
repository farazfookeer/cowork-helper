# Inbox Cleanup – starter prompt

You need an email connector set up first (see `Connector-Picker.md`). Once that is done, paste this:

> Look at every unread email in my inbox from the last 14 days. Do not change anything yet. Group them into four buckets: reply needed (with rough urgency, today / this week / no rush), read but no reply, newsletter or FYI, and archive or delete. For each email in the "reply needed" bucket, give me a one-sentence summary of what they are asking. Save the result as triage.md in this folder.

Once you have the triage file, the natural follow-ups are:

> For the "today" emails in triage.md, draft three different replies for each one (different outcomes, not just different tones). Save as drafts.md. Do not send anything.

> Show me what you would put in "archive or delete". I want to see the list before you touch anything.

For ongoing rhythm, set up a recurring weekly task (see task 10 in `First-10-Tasks.md`):

> Every Friday at 4pm, run the same triage on emails from the past week. Save it as triage-friday.md, overwriting last week's. This is a checking-in habit, not a permanent record.
