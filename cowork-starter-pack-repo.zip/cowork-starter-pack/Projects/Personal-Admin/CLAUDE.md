# Personal Admin – workspace instructions

This Project is for organising the everyday digital mess of life: receipts, statements, household paperwork, photo backlogs, and the contents of folders nobody has the patience to sort.

## About the user

User name: [to be filled by bootstrap]
Risk preference: [to be filled by bootstrap]

If risk preference is `cautious`, default to Ask mode for every action and propose plans before executing them. If `neutral`, propose then execute in single steps. If `fast`, batch related actions and report a summary at the end. Never delete anything permanently without explicit confirmation, regardless of risk preference.

## What this Project expects

The user will drop folders or individual files into this Project's working folder. Typical contents:

- PDFs of statements, bills, and receipts
- Photos that need sorting or renaming
- Forms that need filling
- Folders downloaded from somewhere that need cleaning up
- Documents that need to be filed sensibly

## Working preferences

**Naming convention.** When renaming files, default to: `YYYY-MM-DD-vendor-shorttype.ext`. Example: `2026-03-14-amazon-receipt.pdf`. Use lowercase, hyphens not underscores. Ask if a file does not have a clear date.

**Folder structure.** Default to a flat structure with a small number of clear top-level folders (e.g., `Bills`, `Receipts`, `Tax`, `Personal Documents`, `To Action`). Avoid deep nesting unless the user asks for it. Do not create folders called "Misc" or "Other" – if something does not fit, surface it for the user to decide.

**Spreadsheets.** When extracting data into a spreadsheet, save as `.xlsx` and put the source filename in the rightmost column for traceability. Format dates as ISO (YYYY-MM-DD), not regional format.

**Sensitive documents.** If you encounter what appears to be a passport, ID card, NI/SSN number, full bank account number, or medical record, pause and tell the user before doing anything with the file. Do not include sensitive numbers in any output spreadsheet or summary unless the user has explicitly asked for that.

## What to do at the start of every new task

1. List the files in the working folder so the user can confirm you are looking at the right things.
2. Restate the task in your own words before acting.
3. If the task involves more than ten files, propose your approach as a plan before executing.
