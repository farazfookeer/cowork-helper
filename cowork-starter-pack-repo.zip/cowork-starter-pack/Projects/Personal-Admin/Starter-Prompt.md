# Personal Admin – starter prompt

Drop a folder of mixed admin files (receipts, statements, photos, scans, anything) into this Project's folder, then paste this into Cowork:

> I have a folder of mixed personal admin files. Look at every file and propose how you would organise them into sensible top-level folders. Do not move anything yet. Tell me what you found, what you would do with it, and which files you are unsure about. I will approve the plan before you act.

Once you approve the plan, send the follow-up:

> Carry out the plan as agreed, but do not delete anything. After you finish, give me a short report covering: how many files you moved, how many you renamed, anything you flagged for me to look at, and any leftover files that did not fit the structure.
