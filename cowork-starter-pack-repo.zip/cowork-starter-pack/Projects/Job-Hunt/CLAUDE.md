# Job Hunt – workspace instructions

This Project is for running a job search end to end: tailoring CVs and cover letters, tracking applications, researching employers, and prepping for interviews.

## About the user

User name: [to be filled by bootstrap]
Risk preference: [to be filled by bootstrap]

If risk preference is `cautious`, never send anything on the user's behalf and always show drafts. If `neutral`, draft and prepare files but require explicit approval before submission. If `fast`, prepare materials in batch but still never submit applications without confirmation. Job applications are always a confirm-before-act action, regardless of risk preference.

## What this Project expects

The user will keep these things in or near this Project folder:

- A master CV (their longest, most complete version)
- A few example cover letters that show their voice
- Job descriptions they are interested in (PDFs, screenshots, or text files)
- A spreadsheet or markdown file tracking applications

## Working preferences

**Tailoring CVs and cover letters.** When asked to tailor a CV or cover letter to a job, work from the master document. Do not invent experience or qualifications the user does not have. If the job description requires something the user has not done, flag it as a gap rather than fudging it.

**Voice.** Match the voice in the user's example cover letters, not generic application-letter tone. If the examples are direct and concise, do not pad. If the examples are warm and personal, do not be clinical.

**Application tracker.** Maintain a file called `applications.md` (or `applications.xlsx` if the user prefers) with columns: company, role, source (where the listing was found), date applied, status, deadline if any, notes. Update it after every tailoring task.

**Research before tailoring.** Before tailoring an application, do a quick read of the company: what they do, who their competitors are, recent news. Use this to inform the cover letter. Do not include obvious-from-Wikipedia facts that signal "I just looked you up".

**Interviews.** When asked to prep for an interview, produce: five questions they are likely to ask, three questions you should ask them back, and one specific thing about this company you can reference to show you have done your homework.

## What to never do

- Submit any application without explicit per-application confirmation.
- Use buzzwords like "synergy", "leverage", "passionate about", "results-driven", or "team player" unless the user already uses them in their example letters.
- Fabricate metrics. If the user says "increased revenue", do not invent a percentage.
- Add references to skills or technologies the user has not mentioned anywhere in their CV.
