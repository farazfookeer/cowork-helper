# Job Hunt – starter prompt

Put your master CV, two or three example cover letters, and a job description (PDF or text file) you are interested in into this Project's folder. Then paste this into Cowork:

> I have my master CV, some example cover letters, and a job description in this folder. Read all of it. Tell me: how well I match the role on a scale of 1 to 10, the three strongest matches between my experience and what they want, the two biggest gaps and how to address them, and one piece of the job description that gives a real clue about what they actually care about beyond the bullet points. Do not write a cover letter yet. I want to see what you noticed first.

If you like what comes back, follow up with:

> Now draft a tailored CV and cover letter for this role. Use the voice in my example letters, not generic application tone. Save them as cv-tailored.docx and cover-letter.docx. Add this application to applications.md with status "drafted, not sent".
