# Writing – starter prompt

Drop into the Project folder: a brief or outline of what you want written, any source material it should draw from, and one or two examples of your previous writing so Cowork can learn your voice. Then paste:

> I want to draft [WHAT, AND ROUGHLY HOW LONG]. The brief is in this folder. The source material is in this folder. The files I have written previously are also in this folder, and I want the output in that same voice. Read everything first. Before drafting, tell me back: what you understood the brief to be, what voice you picked up from my previous writing, and what you plan to cover. Wait for me to confirm before you write anything.

When you are happy with the plan, send:

> Now write the first draft. Mark anywhere you guessed at facts or felt thin with [CHECK] in the text. Save it as draft-v1.md.

The most useful follow-up after a first draft:

> What is the weakest part of this draft and why? Do not fix it. Just tell me. I want to make the call about what to do.
