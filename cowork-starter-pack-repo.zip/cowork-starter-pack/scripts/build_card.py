"""
Ask-vs-Act-Card.pdf
A printable one-pager. Two columns. Designed for A4, prints fine on Letter.
Black and white friendly. No images required.

Usage:
    pip install reportlab
    python scripts/build_card.py
"""
import os
from reportlab.lib.pagesizes import A4
from reportlab.lib.units import mm
from reportlab.lib import colors
from reportlab.pdfgen import canvas

# Output to the repo root (one level up from scripts/)
HERE = os.path.dirname(os.path.abspath(__file__))
REPO_ROOT = os.path.dirname(HERE)
OUT = os.path.join(REPO_ROOT, "Ask-vs-Act-Card.pdf")

PAGE_W, PAGE_H = A4
MARGIN = 15 * mm

# Layout
COL_GAP = 6 * mm
COL_W = (PAGE_W - 2 * MARGIN - COL_GAP) / 2

# Colors (subtle, print-friendly)
DARK = colors.HexColor("#111111")
MID = colors.HexColor("#444444")
LIGHT = colors.HexColor("#888888")
RULE = colors.HexColor("#cccccc")
ASK_BG = colors.HexColor("#f4f7fb")
ACT_BG = colors.HexColor("#fbf6f0")
ASK_RULE = colors.HexColor("#2a4d7a")
ACT_RULE = colors.HexColor("#a85c1f")


def draw_wrapped(c, text, x, y, max_w, font, size, leading, color=DARK):
    """Very small word-wrap helper. Returns the y after the last line."""
    c.setFont(font, size)
    c.setFillColor(color)
    words = text.split()
    line = ""
    for w in words:
        test = (line + " " + w).strip()
        if c.stringWidth(test, font, size) <= max_w:
            line = test
        else:
            c.drawString(x, y, line)
            y -= leading
            line = w
    if line:
        c.drawString(x, y, line)
        y -= leading
    return y


def draw_bullets(c, items, x, y, max_w, font, size, leading, indent=4 * mm):
    for item in items:
        c.setFont(font, size)
        c.setFillColor(DARK)
        c.drawString(x, y, "•")
        # wrap the bullet text
        words = item.split()
        line = ""
        first = True
        cur_y = y
        for w in words:
            test = (line + " " + w).strip()
            if c.stringWidth(test, font, size) <= max_w - indent:
                line = test
            else:
                c.drawString(x + indent, cur_y, line)
                cur_y -= leading
                line = w
                first = False
        if line:
            c.drawString(x + indent, cur_y, line)
            cur_y -= leading
        y = cur_y - 1 * mm
    return y


def column(c, x, top_y, bottom_y, w, title, subtitle, accent, bg, when_items, examples_items):
    # Tinted background
    c.setFillColor(bg)
    c.setStrokeColor(bg)
    c.rect(x, bottom_y, w, top_y - bottom_y, fill=1, stroke=0)

    # Accent rule on top
    c.setStrokeColor(accent)
    c.setLineWidth(2)
    c.line(x, top_y - 2, x + w, top_y - 2)

    pad = 6 * mm
    cur_y = top_y - 10 * mm

    # Title
    c.setFillColor(accent)
    c.setFont("Helvetica-Bold", 18)
    c.drawString(x + pad, cur_y, title)
    cur_y -= 6 * mm

    # Subtitle / one-line definition
    c.setFillColor(MID)
    cur_y = draw_wrapped(c, subtitle, x + pad, cur_y, w - 2 * pad,
                         "Helvetica-Oblique", 9.5, 12, color=MID)
    cur_y -= 3 * mm

    # When to use
    c.setFillColor(DARK)
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x + pad, cur_y, "When to use it")
    cur_y -= 5 * mm
    cur_y = draw_bullets(c, when_items, x + pad, cur_y, w - 2 * pad,
                         "Helvetica", 9.5, 12)
    cur_y -= 2 * mm

    # Examples
    c.setFillColor(DARK)
    c.setFont("Helvetica-Bold", 11)
    c.drawString(x + pad, cur_y, "Examples")
    cur_y -= 5 * mm
    cur_y = draw_bullets(c, examples_items, x + pad, cur_y, w - 2 * pad,
                         "Helvetica", 9.5, 12)
    return cur_y


def build():
    c = canvas.Canvas(OUT, pagesize=A4)

    # --- Header
    title_y = PAGE_H - MARGIN - 4 * mm
    c.setFillColor(DARK)
    c.setFont("Helvetica-Bold", 22)
    c.drawString(MARGIN, title_y, "Ask vs Act")

    c.setFillColor(MID)
    c.setFont("Helvetica", 10.5)
    c.drawString(MARGIN, title_y - 6 * mm,
                 "The two modes Cowork runs in. Pick deliberately. Print this. Stick it next to the keyboard.")

    # Top rule
    c.setStrokeColor(RULE)
    c.setLineWidth(0.5)
    c.line(MARGIN, title_y - 10 * mm, PAGE_W - MARGIN, title_y - 10 * mm)

    # --- Two columns
    col_top = title_y - 14 * mm
    col_bottom = MARGIN + 38 * mm  # leave room for footer block

    ask_x = MARGIN
    act_x = MARGIN + COL_W + COL_GAP

    column(
        c, ask_x, col_top, col_bottom, COL_W,
        title="ASK",
        subtitle="Cowork pauses before each step and waits for your approval. Slower, but you see everything.",
        accent=ASK_RULE,
        bg=ASK_BG,
        when_items=[
            "You are new to Cowork or to a particular task type.",
            "Files matter and you cannot easily roll back changes.",
            "You are using a connector for the first time.",
            "The task touches more than a handful of files.",
            "You are not sitting in front of the screen the whole time.",
            "You are not sure. (Default to Ask whenever this applies.)",
        ],
        examples_items=[
            "Reorganising a folder with documents you actually care about.",
            "First time letting Cowork draft replies from your inbox.",
            "Bulk-renaming photos by date and event.",
            "Editing a long document where you want to see each change.",
        ],
    )

    column(
        c, act_x, col_top, col_bottom, COL_W,
        title="ACT",
        subtitle="Cowork runs straight through and reports back at the end. Faster, but you cannot intervene mid-step.",
        accent=ACT_RULE,
        bg=ACT_BG,
        when_items=[
            "You have done this exact task before and trust the pattern.",
            "The task is reversible. Worst case, you re-run it.",
            "You are actively watching and ready to hit stop.",
            "Files are throwaway, sandboxed, or backed up.",
            "Speed matters more than oversight for this task.",
        ],
        examples_items=[
            "Tidying a Downloads folder you have already had Cowork organise once.",
            "Pulling data from receipts into a spreadsheet (read-only on sources).",
            "Generating drafts of writing where you will edit afterwards anyway.",
            "Running a research task that only writes to one output file.",
        ],
    )

    # --- Footer block: rules and default
    foot_top = col_bottom - 4 * mm
    c.setStrokeColor(DARK)
    c.setLineWidth(1)
    c.line(MARGIN, foot_top, PAGE_W - MARGIN, foot_top)

    foot_y = foot_top - 7 * mm
    c.setFillColor(DARK)
    c.setFont("Helvetica-Bold", 12)
    c.drawString(MARGIN, foot_y, "Three ground rules for both modes")
    foot_y -= 5 * mm

    rules = [
        "Cowork will always ask before permanently deleting, regardless of mode.",
        "You can switch modes mid-session. If Act starts feeling risky, switch to Ask.",
        "If something looks wrong, hit stop. Do not argue with a running task.",
    ]
    foot_y = draw_bullets(c, rules, MARGIN, foot_y, PAGE_W - 2 * MARGIN,
                          "Helvetica", 9.5, 12)

    # Big default line at the bottom
    foot_y -= 2 * mm
    c.setFillColor(ASK_RULE)
    c.setFont("Helvetica-Bold", 13)
    c.drawString(MARGIN, foot_y, "When in doubt, default to ASK.")

    c.setFillColor(LIGHT)
    c.setFont("Helvetica-Oblique", 8.5)
    c.drawRightString(PAGE_W - MARGIN, MARGIN - 3 * mm, "Cowork Starter Pack  •  Print and keep")

    c.showPage()
    c.save()
    print(f"Saved: {OUT}")


if __name__ == "__main__":
    build()
