# Cowork Starter Pack

A drop-in starter kit for non-technical people who have just installed Claude Cowork and have no idea what to do next.

Most of the friction with Cowork is not the install. It is the blank page that follows. This pack gives you ready-made workspaces, ten copy-paste tasks ranked from safest to most ambitious, a printable one-page guide on when to let Cowork run versus when to make it ask, a connector picker, and a panic-button page for when something goes wrong. Free, MIT-licensed, no signup, no tracking.

## Get the pack

Two ways:

**Download.** Click the green `Code` button above, then `Download ZIP`. Unzip wherever you want.

**Clone.**

```bash
git clone https://github.com/YOUR-USERNAME/cowork-starter-pack.git
```

Either way, you end up with a folder called `cowork-starter-pack` on your computer. That folder is the pack.

## What you need

- A paid Claude plan (Pro, Max, Team, or Enterprise). Cowork is not on the free tier.
- Claude Desktop installed from [claude.com/download](https://claude.com/download).
- About 10 minutes for setup, plus 5 minutes for your first task.

## The 10-minute setup

1. **Move the unzipped folder somewhere sensible.** Drag `cowork-starter-pack` into your `Documents` folder. That is its home from now on.

2. **Open Claude Desktop.** Sign in.

3. **Click the Cowork tab** at the top of the Claude window. If you do not see it, you are either on a free plan or your app needs updating.

4. **Attach this folder.** In Cowork, look for the option to attach a folder or workspace. Point it at the `cowork-starter-pack` folder.

5. **Paste this exact prompt** into the Cowork chat box and press send:

   > Read BOOTSTRAP.md and set me up.

That is it. Claude reads the bootstrap file, asks a few short questions, and walks you through the rest. It picks the right Project to start with, recommends which connectors to set up, and tees up your first task.

## What is in this pack

| File | What it is for |
|------|----------------|
| `BOOTSTRAP.md` | The setup script Claude reads. You do not need to read it yourself. |
| `Glossary.md` | Six words Cowork uses a lot. Read this if jargon is bothering you. |
| `First-10-Tasks.md` | Ten copy-paste prompts, ranked from safest to most ambitious. |
| `Connector-Picker.md` | Which apps to plug into Cowork first, and which to leave alone. |
| `When-It-Goes-Wrong.md` | What to do if Cowork does something you did not expect. Read this BEFORE you need it. |
| `Ask-vs-Act-Card.pdf` | One-page printable. The single most useful page in this pack. Print it. |
| `Projects/` | Five ready-made workspaces for common life and work tasks. |
| `scripts/build_card.py` | Source for the PDF card, in case you want to fork the design. |

## A few things to know before you start

**Cowork can change your files.** That is the whole point. It can rename, sort, edit, and delete things on your computer. This is powerful and occasionally scary. Read `When-It-Goes-Wrong.md` early. Print the Ask vs Act card. Start with low-stakes tasks until you trust it.

**Cowork is not magic.** It will sometimes get things wrong, misunderstand you, or wander off course. You are the supervisor. The skill you are learning is not "how to write the perfect prompt", it is "how to steer a confident assistant who occasionally needs correcting".

**Your computer needs to be awake.** If your laptop sleeps, Cowork stops. Plug it in for long tasks.

**Start small.** The First-10-Tasks list begins with a task you can finish in five minutes that produces something useful. Do that one first. Build from there.

## Contributing

Issues and pull requests welcome. The most valuable contributions are:

- Better starter prompts in `First-10-Tasks.md`, especially for use cases not covered yet.
- New `Projects/` workspaces (each is just a folder with a `CLAUDE.md` and a `Starter-Prompt.md`).
- Real-world failure stories that should be added to `When-It-Goes-Wrong.md`.
- Translations.

Keep the tone plain-English, no jargon, no AI buzzwords. The audience is a non-technical person who has paid for Claude and wants it to actually do something useful for them.

## License

MIT. Use it, fork it, rebrand it, charge for variants of it. Just keep the licence file with the source.

## Regenerating the printable card

If you want to modify the Ask vs Act card:

```bash
pip install reportlab
python scripts/build_card.py
```

This rebuilds `Ask-vs-Act-Card.pdf` in the repo root.
