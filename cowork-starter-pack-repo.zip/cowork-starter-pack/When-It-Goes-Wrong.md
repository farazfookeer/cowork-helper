# When it goes wrong

Read this page now, before anything goes wrong. The whole point is that you know what to do in the moment of panic instead of having to figure it out from scratch.

## The most important shortcut

**Stop button.** At the top of the Cowork chat window there is a stop button while a task is running. It looks like a square or "stop" icon. Pressing it interrupts whatever Cowork is doing within a second or two. This is your single most useful skill. Practice using it on a low-stakes task so your finger knows where to go.

If you do not see a stop button, closing the Cowork tab also stops the task. Closing the whole Claude Desktop app definitely stops it.

## Common situations

### Cowork is doing something I did not expect

**What to do right now:** Hit stop. Do not try to argue with it mid-task.

**Then:** Tell it what went wrong in plain English. "You started moving files in the Photos folder. I only wanted you to look at the Documents folder." Cowork will acknowledge and adjust. You do not need to start a new chat.

**To prevent next time:** Be more specific in the original prompt about which folder, which files, which output. The single biggest cause of "Cowork did the wrong thing" is "I was not specific enough about the right thing".

### Cowork renamed or moved files I did not want changed

**What to do right now:** Stop the task. Then ask: "Tell me every file you moved or renamed in the last task, with the original name and the new name."

Cowork keeps track of what it did during a session. Get the list. Now you can decide whether to put things back.

**To put things back:** You can ask Cowork to reverse the changes. "Move every file you moved back to its original location and restore the original filenames." This usually works for renames and moves done in the same session.

**The big caveat:** If your computer had any kind of automatic sync running while Cowork worked (iCloud, Drive sync, OneDrive), the changes have already propagated. Reversing them locally still works, but you may see brief sync churn.

### Cowork deleted something

**Stop. Breathe.** Cowork is supposed to ask before permanently deleting anything. If something is missing:

1. **Check your Trash or Recycle Bin first.** Most "deletes" are moves to Trash, which means the file is recoverable with one click.

2. **Check your cloud storage's version history.** Google Drive, OneDrive, and Dropbox all keep recent versions of files for at least 30 days. Right-click the file (or the folder it was in) and look for "version history" or "restore".

3. **Check Time Machine (Mac) or File History (Windows)** if you have it set up.

If none of those work, ask Cowork: "What exactly did you delete in the last task and why?" The answer may help you understand whether it actually deleted, or just moved or renamed something you have not noticed yet.

### Cowork is stuck in a loop or going on forever

**What to do right now:** Hit stop. Do not wait for it to finish on its own. Some tasks run for many minutes legitimately (research across lots of files), but if Cowork has been "thinking" for over five minutes with no visible progress, something has gone wrong.

**Then:** Start a new task with a more bounded prompt. Add explicit limits: "spend no more than 5 minutes on this", "look at no more than 20 files", "if you have not finished after one pass, stop and tell me what you found".

### Cowork is asking too many questions and not getting on with it

This is usually because you put it in Ask mode and it is doing exactly what Ask mode is supposed to do. Two options:

1. **Switch to Act mode** if the task is genuinely safe (read-only, or you trust it). Look for the mode switch in the Cowork settings.

2. **Tell it what to assume.** "For anything you would otherwise ask me, default to [SENSIBLE CHOICE] and tell me what you decided in your final summary." This is the middle path between Ask and Act.

### Cowork misunderstood me and I cannot get it back on track

If you have explained yourself twice and Cowork is still off track, do not keep arguing. **Start a new chat** in the same Project. The previous chat will still be there if you need to refer back, but a fresh chat is fresh context.

When you start the new chat, lead with what went wrong: "I was working on X. The previous attempt got stuck because [WHAT]. This time, do [SPECIFIC NEW APPROACH]." Cowork will read the Project's CLAUDE.md and pick up where it should have been.

### Cowork wants to download something and I am not sure

**Default answer is no.** Cowork should ask before downloading any file. If a task involves downloading from a website, only approve if:

1. You recognise the source.
2. The file type is what you expect (PDF, docx, xlsx, image).
3. The filename makes sense.

If anything looks off, decline and ask Cowork to describe the file in more detail before trying again.

### A connector stopped working

Disconnect and reconnect it. Settings → Connectors → click the connector → disconnect → reconnect. Nine times out of ten, this fixes it. Authorisation tokens expire and need refreshing.

## When to ask for help versus push through

**Push through if:** Cowork made a mistake but the consequence is reversible. You will learn faster by recovering than by avoiding.

**Ask for help if:** Something has gone genuinely wrong with files you cannot afford to lose, your work computer is doing things your IT department would not like, or you are getting login or security warnings you do not understand.

Anthropic Help Center: support.anthropic.com.

## One ground rule that will save you most of the time

**Never start a destructive task without a backup.** If you are about to ask Cowork to reorganise, rename, or delete files in a folder you care about, copy the folder somewhere else first. A two-minute copy saves an hour of recovery. This is true with or without AI involved. It is just true.
