# Glossary

Six words Cowork uses a lot. Two sentences each. If you are getting stuck on any of these terms, this page is for you.

## Project

A Project is a workspace inside Cowork that groups related tasks together. Each Project has its own folder, its own context, and remembers what you have asked it to do before, so you do not have to re-explain yourself every time you come back to it.

## Skill

A Skill is a small instruction file that tells Claude how to handle a specific kind of work, like writing a report a particular way, formatting a spreadsheet, or following your team's tone of voice. You can think of it as a recipe Claude follows so the output is consistent every time.

## Plugin

A Plugin is a bundle of skills, connectors, and prompts pre-packaged for a specific role or workflow. Anthropic ships ready-made plugins for things like sales, finance, and HR, and you can install them from inside Cowork without writing anything yourself.

## Connector

A Connector is a link between Cowork and another app, like Gmail, Google Drive, or Slack. Once you connect an app, Cowork can read from it and (with permission) act on it, so you can ask it to "summarise unread emails from this week" or "save the meeting notes to Drive".

## Memory

Memory is what Cowork remembers about you and your work between sessions. Inside a Project, memory is on by default and useful, so Cowork stops asking you the same questions twice. Outside Projects, in standalone tasks, memory does not carry across sessions.

## Mode (Ask vs Act)

Mode is the setting that controls whether Cowork pauses to ask permission before each step (Ask), or runs straight through (Act). Ask is the safer default, Act is faster but riskier, and even in Act mode Cowork will still pause before deleting anything permanently.
