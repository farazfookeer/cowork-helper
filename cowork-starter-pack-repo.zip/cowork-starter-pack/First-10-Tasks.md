# Your first 10 tasks

Ten copy-paste prompts, ordered from safest first win to more ambitious. Do them in order. Do not skip ahead until you have done at least three.

Each task includes:

- **What it does** – plain English
- **Why start here** – what you will learn
- **Time** – realistic estimate
- **Mode** – Ask or Act (read the Ask vs Act card if unsure)
- **Prompt** – paste this directly into Cowork

If a task asks you to provide source files, drop them into the relevant Project folder before starting. Cowork can only see files you have given it.

---

## 1. Summarise a long PDF

**What it does:** Reads a document up to 100 pages long and gives you a one-page summary with the key points and any numbers worth noting.
**Why start here:** Zero risk to your files. Pure read-only. Builds confidence fast.
**Time:** 3 to 8 minutes.
**Mode:** Ask.
**Prompt:**

> Read the PDF I just dropped in this folder. Give me a one-page summary with three sections: what this document is, the five most important points, and any numbers, dates, or names I should remember. Do not change any files.

---

## 2. Compare two documents for differences

**What it does:** Looks at two versions of a document and lists exactly what changed, what stayed the same, and what is missing.
**Why start here:** Still read-only. Teaches you that Cowork can hold two things in its head at once.
**Time:** 5 minutes.
**Mode:** Ask.
**Prompt:**

> I have two documents in this folder. Compare them side by side. Tell me what changed between version A and version B, what is new, what was removed, and whether any of the changes look like mistakes I should double check.

---

## 3. Tidy up a downloads folder (preview only)

**What it does:** Looks at a messy folder and proposes a tidy structure, without actually moving anything yet.
**Why start here:** This is the safe version of the task that scares people most. You see what Cowork would do before you let it do it.
**Time:** 5 minutes.
**Mode:** Ask.
**Prompt:**

> Look at all the files in my Downloads folder. Do not move or rename anything. Just give me a proposal for how you would organise it: which folders you would create, which files would go where, and which files look like they could be deleted. I will tell you which parts to actually do after I read your plan.

---

## 4. Tidy up a downloads folder (actually do it)

**What it does:** Same as task 3, but now Cowork carries out the plan you approved.
**Why start here:** First time you let Cowork change real files. Big confidence step.
**Time:** 5 to 15 minutes.
**Mode:** Ask, switching to Act after you approve the plan.
**Prompt:**

> Carry out the tidy-up plan we just agreed. Move and rename files as discussed. Do not delete anything yet. When you have finished, give me a list of every file you moved or renamed so I can spot-check.

---

## 5. Extract data from a stack of receipts or invoices

**What it does:** Reads PDFs or images of receipts and pulls out date, vendor, amount, and category into a clean spreadsheet.
**Why start here:** Saves hours of typing. Demonstrates the multi-file pattern you will use forever after.
**Time:** 5 to 20 minutes depending on how many files.
**Mode:** Ask.
**Prompt:**

> All the files in this folder are receipts or invoices. Read each one and build a spreadsheet with these columns: date, vendor, amount, currency, category (your best guess), and original filename. Save it as receipts.xlsx in the same folder. Flag any receipts where you could not read the amount clearly.

---

## 6. Draft a structured report from source files

**What it does:** Takes a folder of notes, articles, or research and produces a first-draft report in a structure you specify.
**Why start here:** This is the task most people end up using Cowork for once they get hooked. The blank-page killer.
**Time:** 10 to 20 minutes.
**Mode:** Ask.
**Prompt:**

> Read every document in this folder. I need to produce a report titled "[YOUR TOPIC]" for [WHO IT IS FOR]. Draft it with these sections: Executive summary (5 bullets), Background, Findings, Recommendations, Open questions. Pull facts from the source documents and reference them by filename in brackets. Save the draft as report-draft.docx. I will edit from there.

---

## 7. Reply-draft to a tricky email

**What it does:** You paste in the email you received, tell Cowork what you want the reply to achieve, and it drafts three different responses you can pick from.
**Why start here:** Teaches you that Cowork is not a one-shot tool. You can get options and choose.
**Time:** 3 minutes.
**Mode:** Ask. Do not let it send.
**Prompt:**

> I have an email I need to reply to. The sender wrote: [PASTE EMAIL]. My situation is: [WHAT YOU ACTUALLY WANT]. Draft three reply options that lead to different outcomes: one polite no, one firm pushback, one that tries to reframe the conversation. Do not send anything. I will copy the one I like.

---

## 8. Research and compare three options

**What it does:** Picks a decision you are wrestling with, finds three credible options, and produces a comparison table with pros, cons, and a tentative recommendation.
**Why start here:** Demonstrates the research workflow. Useful for any decision over £100.
**Time:** 10 to 15 minutes.
**Mode:** Ask. This task uses web search.
**Prompt:**

> I need to make a decision about [DECISION]. My constraints are: [BUDGET, TIMELINE, ANY MUST-HAVES]. Find three credible options online, compare them in a table covering cost, key features, and one risk for each. End with your tentative recommendation and what you would want to know before committing. Save it as decision-notes.md.

---

## 9. Extract action items from meeting notes

**What it does:** Reads messy meeting notes and produces a clean list of who is doing what by when.
**Why start here:** Turns a tedious end-of-week task into a 30-second prompt.
**Time:** 2 to 5 minutes.
**Mode:** Ask.
**Prompt:**

> Read the meeting notes in this folder. Produce a clean list of action items in this format: who, what, by when. Group by person. If a deadline was not mentioned, write "no deadline given" rather than guessing. Flag anything that sounds like it needed a decision but did not get one.

---

## 10. Set up a recurring weekly task

**What it does:** Tells Cowork to run a useful task every Monday morning, like a briefing of your week ahead pulled from your calendar and email.
**Why start here:** Last because it requires connectors set up. Most powerful once it works.
**Time:** 10 minutes to set up, then runs forever.
**Mode:** Ask the first time. Switch to Act once you trust it.
**Prompt:**

> Every Monday at 8am, run this task: read my calendar for the week, summarise meetings I have, flag any that look unprepared, and pull any urgent emails I have not replied to from the last three days. Output it as a one-page briefing in this folder called week-ahead.md. Do not send anything to anyone.

---

## What to do once you have done a few

After three or four of these, you will start having ideas of your own. Good. Use the same shape as the prompts above: tell Cowork what to read, what you want back, where to save it, and what NOT to do. That is 90% of the skill.
