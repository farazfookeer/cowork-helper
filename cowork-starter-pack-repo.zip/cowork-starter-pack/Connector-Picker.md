# Connector picker

Cowork can plug into dozens of apps. You do not need most of them. The temptation is to "connect everything" and figure it out later. Resist that.

Connect one app. Use it for a week. Add the next one only when you hit a task that genuinely needs it.

## How to add a connector

In Claude Desktop, open Settings → Connectors → Browse connectors. Pick one from the list. Click Connect. You will be taken to the app's normal sign-in page, you log in, you approve access, you come back. That is the whole flow.

You never enter passwords or financial details inside Cowork itself. If a connector setup ever asks you to type a password into a Cowork window rather than the app's own sign-in page, stop and check `When-It-Goes-Wrong.md`.

## The shortlist

Connect these in this order. Stop when you have enough.

### 1. Email (Gmail or Outlook)

**Why first:** Email is where work hides. Once Cowork can read your inbox, half the "I need to find that thing" problem disappears.

**What it lets you do:**

- Summarise unread emails
- Find an attachment you got three months ago
- Draft replies in your voice
- Pull all emails from one sender or about one topic into a single document

**What it can NOT do without you watching:** Send emails on your behalf. By design, Cowork drafts and you send. Keep it that way.

### 2. File storage (Google Drive, OneDrive, or Dropbox)

**Why second:** This makes Cowork useful from your phone too. Drop a file in Drive on your phone, ask Cowork to do something with it from your laptop.

**What it lets you do:**

- Search across all your cloud files
- Save Cowork's outputs straight to Drive instead of your laptop
- Pull source material from a shared folder

**Pick one.** If you use Google Drive at work and OneDrive at home, connect the one where your important files live. Adding the second later takes 30 seconds.

### 3. Slack (only if you use it for work)

**Why third:** Slack is where decisions happen but never get written down properly. Cowork can fix that.

**What it lets you do:**

- Summarise a channel from the last week
- Pull all messages from one person on one topic
- Draft a status update based on what you actually did this week

**Skip this if:** You are connecting a Slack workspace you do not own. Some employers do not allow third-party connectors to corporate Slack. Check first.

### 4. Calendar (Google Calendar or Outlook)

**Why fourth:** Useful but rarely transformative on its own. Pairs well with email.

**What it lets you do:**

- Build a Monday-morning briefing of your week
- Find a free 30-minute slot for a recurring task
- Cross-reference meetings with the documents that go with them

## Connectors to ignore for now

These exist, they are real, and they are not where to start:

- **Notion, Linear, Jira, Asana** – useful if your team uses them daily, but each one comes with quirks. Add when you have a specific recurring task.
- **GitHub, AWS, observability tools** – you do not need these as a non-technical user. They are for engineers.
- **Industry-specific connectors** (Salesforce, HubSpot, etc.) – worth it if you live inside the tool, otherwise skip.

## A safety note

Every connector you add is a piece of your digital life that Cowork can now see. This is the point. It is also a real privacy decision. Two ground rules:

1. **Do not connect personal email and work email to the same Cowork session if your employer would not be happy about that.** Disconnecting is easy. Untangling a confused leak is not.

2. **Review connector permissions every few months.** Settings → Connectors shows you what is connected and what each one can see. Disconnect anything you no longer use.
